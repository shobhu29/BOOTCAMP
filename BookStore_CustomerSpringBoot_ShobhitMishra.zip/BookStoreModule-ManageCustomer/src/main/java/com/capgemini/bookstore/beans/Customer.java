package com.capgemini.bookstore.beans;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Customer", uniqueConstraints = { @UniqueConstraint(columnNames = { "email", "mobileNo" }) })
public class Customer {

	@Id
	@Column(name = "customerid")
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int customerId;

	@Column(name = "customername")
	@NotNull
	@Size(min = 8, max = 30)
	private String customerName;

	@Column(name = "email")
	@NotNull
	@Email
	@Size(min = 10, max = 64)
	private String customerEmail;

	@Column(name = "customerpassword")
	@NotNull
//	@Size(min = 8, max = 16)
	private String customerPassword;

	@Column(name = "mobileno")
	@NotNull
//	@Size(max = 10)
	private String customerMobileNumber;

	@Column(name = "address")
	@NotNull
//	@Size(min = 10, max = 128)
	private String customerAddress;

	@Column(name = "city")
	@NotNull
//	@Size(min = 3, max = 32)
	private String customerCity;

	@Column(name = "zipcode")
//	@Size(min = 3, max = 24)
	@NotNull
	private String customerZipcode;

	@Column(name = "country")
	@NotNull
//	@Size(min = 3, max = 64)
	private String customerCountry;

	@Column(name = "registerdate")
	@NotNull
	private LocalDate customerRegisterDate;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerMobileNumber() {
		return customerMobileNumber;
	}

	public void setCustomerMobileNumber(String customerMobileNumber) {
		this.customerMobileNumber = customerMobileNumber;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

	public String getCustomerCity() {
		return customerCity;
	}

	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}

	public String getCustomerZipcode() {
		return customerZipcode;
	}

	public void setCustomerZipcode(String customerZipcode) {
		this.customerZipcode = customerZipcode;
	}

	public String getCustomerCountry() {
		return customerCountry;
	}

	public void setCustomerCountry(String customerCountry) {
		this.customerCountry = customerCountry;
	}

	public LocalDate getCustomerRegisterDate() {
		return customerRegisterDate;
	}

	public void setCustomerRegisterDate(LocalDate customerRegisterDate) {
		this.customerRegisterDate = customerRegisterDate;
	}

	
	
	

}

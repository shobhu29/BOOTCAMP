package com.capgemini.bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.beans.Customer;
import com.capgemini.bookstore.dao.IManageCustomerRepo;

@Service
public class ManageCustomerServiceImpl implements IManageCustomerService {
	
	@Autowired
	IManageCustomerRepo managecustomerrepo;
	
	@Override
	public List<Customer> listAllCustomers() {
	
		return managecustomerrepo.findAllCustomers();
	}

	@Override
	public Customer createCustomer(Customer customer) {

		return managecustomerrepo.saveCustomer(customer);
	}

	@Override
	public Customer getCustomer(int customerId) {
		return managecustomerrepo.findCustomerById(customerId);
	}

	@Override
	public void deleteCustomer(int customerId) {
		managecustomerrepo.deleteCustomer(customerId);;
	}

	@Override
	public Customer updateCustomer(Customer customer) {

		return managecustomerrepo.updateCustomer(customer);
	}

}

package com.capgemini.bookstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.capgemini.bookstore.beans.Customer;

@Repository
@Transactional
public class ManageCustomerRepoImpl implements IManageCustomerRepo {

	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public Customer saveCustomer(Customer customer) {
		entitymanager.persist(customer);
		return customer;
	}

	@Override
	public List<Customer> findAllCustomers() {

		return entitymanager.createQuery("select c from Customer c", Customer.class).getResultList();
	}

	@Override
	public Customer findCustomerById(int customerId) {
		return entitymanager.find(Customer.class, customerId);
	}

	@Override
	public void deleteCustomer(int customerId) {

		Customer cust = entitymanager.find(Customer.class, customerId);
		entitymanager.remove(cust);
	}

	@Override
	public Customer updateCustomer(Customer customer) {

//		Customer cust = entitymanager.find(Customer.class, customerId);
//		
//		cust.setCustomerAddress(customer.getCustomerAddress());
//		cust.setCustomerCity(customer.getCustomerCity());
//		cust.setCustomerCountry(customer.getCustomerCountry());
//		cust.setCustomerEmail(customer.getCustomerEmail());
//		cust.setCustomerMobileNumber(customer.getCustomerMobileNumber());
//		cust.setCustomerName(customer.getCustomerName());
//		cust.setCustomerPassword(customer.getCustomerPassword());
//		cust.setCustomerRegisterDate(customer.getCustomerRegisterDate());
//		cust.setCustomerZipcode(customer.getCustomerZipcode());
//		
//		entitymanager.persist(cust);

		return entitymanager.merge(customer);

	}

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './category.component.html',
})
export class CategoryComponent {
}

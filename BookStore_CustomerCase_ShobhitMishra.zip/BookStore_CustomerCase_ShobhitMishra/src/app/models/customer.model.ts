export class Customer {
 
  customerId: number;
  customerName: string;
  customerAddress: string;
  customerCity: string;
  customerZipcode: string;
  customerCountry: string;
  customerEmail: string;
  customerMobileNumber: string;
  customerPassword: string;
  customerRegisterDate: string;

}
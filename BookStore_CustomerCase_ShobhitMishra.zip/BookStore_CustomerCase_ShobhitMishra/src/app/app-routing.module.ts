import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CustomerComponent } from './customer/customer.component';
import { CreateCustomerComponent } from './customer/createcustomer.component';
import { UserComponent } from './user/user.component';
import { CategoryComponent } from './category/category.component';
import { BookComponent } from './book/book.component';

const routes: Routes = [
	{ path: 'customers', component: CustomerComponent },
	{ path: 'createcustomers', component: CreateCustomerComponent },
	{ path: 'users', component: UserComponent },
	{ path: 'books', component: BookComponent },
	{ path: 'categories', component: CategoryComponent },
  
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }

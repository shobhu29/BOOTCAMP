import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
 
import { Customer } from '../models/customer.model';
 
 
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
 
@Injectable()
export class CustomerService {
 
  constructor(private http:HttpClient) {}
 
  private customerUrl = 'http://localhost:8088/listAllCustomers';
  
  private customerUrl1 = 'http://localhost:8088/createCustomer';
 
  private customerUrl2 = 'http://localhost:8088/deleteCustomer';
  
  private customerUrl3 = 'http://localhost:8088/updateCustomer';

 
  public getCustomers() {
    return this.http.get<Customer[]>(this.customerUrl);
  }

	public createCustomer(customer) {
		return this.http.post(this.customerUrl1, customer);
  }
  
   public deleteCustomer(customer) {
    return this.http.delete(this.customerUrl2 + "/" + customer.customerId);
	}
	
  public updateCustomer(customer) {
		return this.http.put(this.customerUrl3, customer);
  }
 
}
import { Component } from '@angular/core';
import { Router } from '@angular/router';
 
import { Customer } from '../models/customer.model';
import { CustomerService } from './customer.service';

@Component({
	
  templateUrl: './createcustomer.component.html',
   styleUrls: ['./createcustomer.component.css']
})
export class CreateCustomerComponent {
	 
	customer: Customer = new Customer();
 
  constructor(private customerService: CustomerService) {
 
  }
 
  createCustomer(): void {
    this.customerService.createCustomer(this.customer)
        .subscribe( data => {
          alert("Customer created successfully.");
        });
 
  };
	
}
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './book.component.html',
})
export class BookComponent {
}
